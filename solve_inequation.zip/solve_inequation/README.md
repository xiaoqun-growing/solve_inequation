# solve_inequation

solving inequation is a nonlinear dynamic programming problem. It is not convenient to slove this question and get an curved surface.
So, i just use random choice tool generate enough root to approach this solution.
